package edu.towson.cis.cosc603.project3.vendingmachine;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import edu.towson.cis.cosc603.project3.vendingmachine.VendingMachine;
import edu.towson.cis.cosc603.project3.vendingmachine.VendingMachineItem;

/**
 * Here the method makePurchase() is tested
 * @author Henrys Laptop 2
 *
 */
public class testMakePurchase {

	private VendingMachine myMachine;
	private VendingMachineItem item;
	
	@Before
	public void setUp() throws Exception {
		myMachine = new VendingMachine();
		item = new VendingMachineItem("Snickers", 1.00);
		myMachine.addItem(item, "A");
	}

	@Test
	public void testMakePurchase() {
		myMachine.insertMoney(1);
		assertTrue(myMachine.makePurchase("A"));
	}

}
