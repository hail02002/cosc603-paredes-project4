package edu.towson.cis.cosc603.project3.vendingmachine;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import edu.towson.cis.cosc603.project3.vendingmachine.VendingMachine;

/**
 * Here the method insertMoney precondition
 * and postcondition is being tested
 * @author Henrys Laptop 2
 *
 */
public class testInsertMoney {

	private VendingMachine myMachine;
	
	@Before
	public void setUp() throws Exception {
		myMachine = new VendingMachine();
	}


	@Test
	public void testInsertMoney() {
		double startAmount = 0.50;
		myMachine.insertMoney(startAmount);
		assertEquals(myMachine.getBalance(), startAmount, 0.0001);
	}

}
