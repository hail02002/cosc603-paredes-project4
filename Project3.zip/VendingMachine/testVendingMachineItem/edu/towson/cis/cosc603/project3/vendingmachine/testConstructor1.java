package edu.towson.cis.cosc603.project3.vendingmachine;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import edu.towson.cis.cosc603.project3.vendingmachine.VendingMachineItem;

/**
 * Here the constructor is test with bad inputs
 * @author Henrys Laptop 2
 *
 */
public class testConstructor1 {

	private VendingMachineItem item;
	
	@Before
	public void setUp() throws Exception {
		item = new VendingMachineItem("snickers", 1);
	}

	@Test
	public void testVendingMachineItem0() {
		assertEquals(item.getName(), "snickers");
	}

	@Test
	public void testVendingMachineItem1() {
		//VendingMachineItem item0 = new VendingMachineItem("snickers", 1); 
		assertEquals(item.getPrice(), 1, 0.0001);
	}

}
